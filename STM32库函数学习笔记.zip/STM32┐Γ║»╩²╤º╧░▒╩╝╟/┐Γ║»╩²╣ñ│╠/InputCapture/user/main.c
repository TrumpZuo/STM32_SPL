
#include <stm32f10x.h>
#include "Inputcapture.h"
#include "OLED.h"
#include "PWM.h"

int main(void){
	
	pwm_init();
	inputCapture_init();
	OLED_Init();
	OLED_ShowString(1,1,"Fre:Hz");
	OLED_ShowString(3,1,"Duty:%");
	while(1){
		
		OLED_ShowNum(2,1,IC_getFre(),5);
		OLED_ShowNum(4,1,IC_getDuty(),5);
	}
	
	
	
	
	
}
