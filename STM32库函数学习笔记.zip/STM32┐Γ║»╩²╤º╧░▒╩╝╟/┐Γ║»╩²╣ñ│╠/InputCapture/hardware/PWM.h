#ifndef __PWM_H
#define __PWM_H

void PWM_init(void);
void pwm_init(void);
#endif

