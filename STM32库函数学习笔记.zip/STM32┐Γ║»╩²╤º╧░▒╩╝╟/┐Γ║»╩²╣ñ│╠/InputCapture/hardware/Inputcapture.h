#ifndef __INPUT_CAPTURE_H
#define __INPUT_CAPTURE_H

void inputCapture_init(void);
uint32_t IC_getFre(void);
uint32_t IC_getDuty(void);
#endif

