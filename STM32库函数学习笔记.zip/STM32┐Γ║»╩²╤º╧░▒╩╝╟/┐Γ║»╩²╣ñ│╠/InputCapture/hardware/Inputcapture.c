#include <stm32f10x.h>

void inputCapture_init(){
	
	GPIO_InitTypeDef GPIO_InitStruct;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_ICInitTypeDef TIM_ICInitStruct;
	
	//对输入 端口进行配置；TIM3 PA6 PA7
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	
	//定时器的时基单元 配置,产生标准的 1MHz 频率方波；
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	TIM_InternalClockConfig(TIM3);
	TIM_TimeBaseInitStruct.TIM_ClockDivision =TIM_CKD_DIV1 ;
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = 65536-1;
	TIM_TimeBaseInitStruct.TIM_Prescaler = 72-1;
	TIM_TimeBaseInitStruct.TIM_RepetitionCounter =0;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStruct);
	
	//输入捕获单元配置
	TIM_ICInitStruct.TIM_Channel = TIM_Channel_1;
	TIM_ICInitStruct.TIM_ICFilter = 0xF;
	TIM_ICInitStruct.TIM_ICPolarity = TIM_ICPolarity_Rising;
	TIM_ICInitStruct.TIM_ICPrescaler = TIM_ICPSC_DIV1;
	TIM_ICInitStruct.TIM_ICSelection = TIM_ICSelection_DirectTI;
	TIM_ICInit(TIM3, &TIM_ICInitStruct);
	
	
	//测量占空比：将第二个通道按照相反的配置
	//TIM_Channel_1 TIM_ICPolarity_Falling TIM_ICSelection_IndirectTI
	//快速配置方法：
	TIM_PWMIConfig(TIM3, &TIM_ICInitStruct);
	
	
	//主从模式配置，全自动测量：
	TIM_SelectInputTrigger(TIM3, TIM_TS_TI1FP1);
    TIM_SelectSlaveMode(TIM3, TIM_SlaveMode_Reset);
	
	TIM_Cmd(TIM3, ENABLE);
}
uint32_t IC_getFre(void){
	//由于 PSC = 72，标准频率是 1MHz
	return 1000000/(TIM_GetCapture1(TIM3)+1);
	
}

uint32_t IC_getDuty(void){
	//由于 PSC = 72，标准频率是 1MHz
	return (TIM_GetCapture2(TIM3)+1)*100/(TIM_GetCapture1(TIM3)+1);
	
}

