#include "stm32f10x.h"   // Device header
#include "led.h"
#include "buzzer.h"
#include "Delay.h"
#include "key.h"
#include "light_sensor.h"

key_state key_num;

int main(void)
{
	
	led_init();
	key_init();
	buzzer_init();
	light_sensor_init();
	
	while(1){
		key_num = key_scan();
		if(key_num == KEY_ON){
			led_turn();	
		}
		if(light_sensor_get()== 1){
			buzzer_turn();
			led_turn();
			Delay_ms(100);
		}
			
		
	
	}
	


}



