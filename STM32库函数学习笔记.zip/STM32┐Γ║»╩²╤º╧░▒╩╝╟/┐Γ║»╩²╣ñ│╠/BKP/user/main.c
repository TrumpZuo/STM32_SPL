#include "stm32f10x.h"  // Device header
#include "OLED.h"
#include "bkp.h"


int main(void){
	OLED_Init();
	
	
	bkp_init();
	rtc_init();


	//OLED_ShowHexNum(1,1,BKP_ReadBackupRegister(BKP_DR1),4);
	while(1){
		rtc_getDate();
		OLED_ShowNum(2, 1,RTC_GetCounter(), 10);
		OLED_ShowNum(3, 1,get_dateArray[3], 3);
		OLED_ShowNum(3, 5,get_dateArray[4], 3);
		OLED_ShowNum(3, 9,get_dateArray[5], 3);
	}


}


