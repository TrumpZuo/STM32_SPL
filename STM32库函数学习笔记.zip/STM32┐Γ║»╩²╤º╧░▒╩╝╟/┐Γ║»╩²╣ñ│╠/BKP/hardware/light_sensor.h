#ifndef __LIGHT_SENSOR_H
#define __LIGHT_SENSOR_H


void light_sensor_init(void);
uint8_t light_sensor_get(void);

#endif

