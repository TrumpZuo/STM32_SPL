#ifndef __ENCODER_H
#define __ENCODER_H

void Encoder_Init(void);


#endif

