#include "stm32f10x.h"
#include "buzzer.h"


void buzzer_init(void){
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);

	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void buzzer_on(void){
	GPIO_SetBits(GPIOA,  GPIO_Pin_1);
}

void buzzer_off(void){
	GPIO_ResetBits(GPIOA,  GPIO_Pin_1);
}
void buzzer_turn(void){
	if( GPIO_ReadOutputDataBit(GPIOA,  GPIO_Pin_1) ==0 ){
		GPIO_SetBits(GPIOA,  GPIO_Pin_1);
	}
	else{
		GPIO_ResetBits(GPIOA,  GPIO_Pin_1);
	}
	
}


