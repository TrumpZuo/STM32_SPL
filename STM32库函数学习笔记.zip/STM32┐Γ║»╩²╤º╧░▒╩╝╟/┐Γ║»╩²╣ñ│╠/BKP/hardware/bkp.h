#ifndef __BKP_H
#define __BKP_H
#include "stm32f10x.h"                  


extern uint16_t get_dateArray[6];

void bkp_init(void);
void rtc_init(void);
void rtc_getDate(void);

#endif 




