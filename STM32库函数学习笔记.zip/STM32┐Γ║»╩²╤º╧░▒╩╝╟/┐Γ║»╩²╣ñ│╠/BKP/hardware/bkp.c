                
#include "stm32f10x.h"     
#include <time.h>
#include "bkp.h" 


uint16_t dateArray[6]= {2024,8,20,15,59,59};
uint16_t get_dateArray[6]= {0};

void rtc_getDate(void){
	time_t dateCnt;
	struct tm date;
	
	dateCnt = RTC_GetCounter();
	 date = *localtime(&dateCnt);
	
	get_dateArray[0] =date.tm_year  + 1900;
	get_dateArray[1] =date.tm_mon + 1;
	get_dateArray[2] =date.tm_mday ;
	get_dateArray[3] =date.tm_hour ;
	get_dateArray[4] =date.tm_min ;
	get_dateArray[5] =date.tm_sec ;
	

}
void rtc_setDate(void){
	time_t dateCnt;
	struct tm date;
	date.tm_year = dateArray[0] - 1900;
	date.tm_mon = dateArray[1] - 1;
	date.tm_mday = dateArray[2];
	date.tm_hour = dateArray[3];
	date.tm_min = dateArray[4];
	date.tm_sec = dateArray[5];
	dateCnt = mktime(&date);
	
	RTC_SetCounter(dateCnt);
	RTC_WaitForLastTask();//ÿ�β���RTC�Ĵ���������ȴ���־λ�ĸı�
	
}

void bkp_init(void){
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_BKP, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
	
	
	PWR_BackupAccessCmd(ENABLE);
	//BKP_WriteBackupRegister(BKP_DR1,0x1024);
}

void rtc_init(void){
	
	
	uint16_t delay = 200;
	
	bkp_init();
	
	RCC_LSEConfig(RCC_LSE_ON);
  RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
	
  RCC_RTCCLKCmd(ENABLE);

	while( RCC_GetFlagStatus(RCC_FLAG_LSERDY)!= SET || delay-- ){};
	
  RTC_WaitForSynchro();
	RTC_WaitForLastTask();
	
	

	RTC_SetPrescaler(32768 -1);
	RTC_WaitForLastTask();
	
	
//	RTC_SetCounter(12345);
//	RTC_WaitForLastTask(); //ÿ�β����Ĵ���������ȴ���־λ�ĸı�
  
	if( BKP_ReadBackupRegister(BKP_DR1) != 0x1024){
		 rtc_setDate();
		BKP_WriteBackupRegister(BKP_DR1,0x1024);
	}
  



}





