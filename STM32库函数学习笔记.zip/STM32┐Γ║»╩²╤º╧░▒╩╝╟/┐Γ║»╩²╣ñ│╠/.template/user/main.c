#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "adc.h"
#include "Delay.h"


int main(void){
	
	uint16_t data;
	float voltage1,voltage2;
	
	OLED_Init();
	//adc_init();
	
	
	//OLED_ShowString(1, 1, "adc1:");
	//OLED_ShowString(2, 1, "adc2:");

	while(1){

		//
		
		// data = adc_conversion(ADC_Channel_1);
		// voltage1 = (float)data / 4095 * 3.3;		
		// OLED_ShowNum(1,6,voltage1,1);
		// OLED_ShowChar(1,7, '.');
		// OLED_ShowNum(1,8,(uint16_t)(voltage1*100) %100,2);
		
		// data = adc_conversion(ADC_Channel_2);
		// voltage2 = (float)data / 4095 * 3.3;		
		// OLED_ShowNum(2,6,voltage2,1);
		// OLED_ShowChar(2,7, '.');
		// OLED_ShowNum(2,8,(uint16_t)(voltage2*100) %100,2);	
		// OLED_ShowHexNum(3,2,0xdddd,8);
		
		// Delay_ms(50);
	}
	
	
	
}




