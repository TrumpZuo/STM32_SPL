#include "stm32f10x.h"                  // Device header
#include "adc.h"



void adc_init(){
	
	ADC_InitTypeDef ADC_InitStruct;
	GPIO_InitTypeDef GPIO_InitStruct;
	//����ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_ADCCLKConfig(RCC_PCLK2_Div6); // 72/6 = 12 < 14
	
	//����GPIO

	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init( GPIOA,&GPIO_InitStruct);
	
	//ADC����

	ADC_StructInit(&ADC_InitStruct);
	ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_Init( ADC1, &ADC_InitStruct);
	//ADC_RegularChannelConfig(ADC1,ADC_Channel_1,1, ADC_SampleTime_7Cycles5);
  
	//ADC_ITConfig( ADC1, ADC_IT_EOC, ENABLE);//�����жϣ�ֱ�Ӷ�ȡ
	ADC_Cmd( ADC1,ENABLE);
	
	//ADC��У׼
	 ADC_ResetCalibration( ADC1);
   while( ADC_GetResetCalibrationStatus( ADC1) == SET)  ;
   ADC_StartCalibration( ADC1);
   while( ADC_GetCalibrationStatus(ADC1) == SET) ;
	
}

uint16_t adc_conversion( uint8_t ADC_Channel){
		
	ADC_RegularChannelConfig(ADC1,ADC_Channel,1, ADC_SampleTime_7Cycles5);
	
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);
	while(ADC_GetFlagStatus( ADC1, ADC_FLAG_EOC) == RESET );
	return ADC_GetConversionValue( ADC1);//ת��������־EOC�����Զ������
}



