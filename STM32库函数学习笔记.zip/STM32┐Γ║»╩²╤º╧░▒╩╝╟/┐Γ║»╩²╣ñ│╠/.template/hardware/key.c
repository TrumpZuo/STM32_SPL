#include "stm32f10x.h"                  // Device header
#include "key.h"                  // Device header
#include "Delay.h"


void key_init(void){
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);

	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStruct);

}
key_state key_scan(void){
	key_state key_num;
	//上拉输入，0为按下
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0) == 0){
		Delay_ms(100);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1) == 0);
		//这里将 一直 等待 按键抬起再处理，应该使用中断；
		key_num = KEY_ON;
		Delay_ms(100);
	}
	else{
		key_num = KEY_OFF;
	}
	return key_num;
	
}

