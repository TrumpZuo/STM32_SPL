#ifndef __KEY_H
#define __KEY_H

typedef enum{
	KEY_OFF = 0,
	KEY_ON
} key_state;

void key_init(void);
key_state key_scan(void);

#endif

