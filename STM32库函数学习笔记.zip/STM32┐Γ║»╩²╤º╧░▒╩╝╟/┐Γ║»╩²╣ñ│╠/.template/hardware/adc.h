#ifndef  __ADC_H
#define __ADC_H
#include "stm32f10x.h"                  // Device header


void adc_init(void);
uint16_t adc_conversion(uint8_t ADC_Channel);



#endif


