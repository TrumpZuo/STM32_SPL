#ifndef __KEY_H
#define __KEY_H


void key_init(void);
uint8_t key_scan(void);

#endif

