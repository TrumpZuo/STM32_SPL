#include "stm32f10x.h"                  // Device header                 
#include "Delay.h"


void key_init(void){
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);

	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStruct);

}
uint8_t key_scan(void){
	uint8_t key_num;
	//上拉输入，0为按下
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0) == 0){
		Delay_ms(10);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0) == 0);
		//这里将 一直 等待 按键抬起再处理，应该使用中断；
		key_num = 1;
		Delay_ms(10);
	}
	else{
		key_num = 0;
	}
	return key_num;
	
}

