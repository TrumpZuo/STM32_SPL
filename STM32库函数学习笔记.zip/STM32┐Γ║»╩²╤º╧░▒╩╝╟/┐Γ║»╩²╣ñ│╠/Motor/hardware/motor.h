#ifndef __MOTOR_H
#define __MOTOR_H

void motor_init(void);
void motor_setSpeed(int16_t speed);

#endif


