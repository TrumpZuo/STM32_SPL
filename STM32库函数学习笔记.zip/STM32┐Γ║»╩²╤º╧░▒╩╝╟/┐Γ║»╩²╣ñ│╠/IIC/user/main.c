#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "adc.h"
#include "Delay.h"
#include "iic.h"
#include "iic_peripheral.h"


int main(void){
	
	OLED_Init();
	mpu6050_init();
	

//	mpu6050_writeData(0x19,0x23);
//	uint8_t ID = mpu6050_readData(0x19);
	
//	IIC_Init();
//	uint8_t Ack; 
//	IIC_Start();
//	IIC_SendByte(0xD2);
//	Ack = IIC_ReceiveAck();

	
//	OLED_ShowString(1, 1, "preFre:");
//	OLED_ShowHexNum(2,1,ID,4);
//  OLED_ShowString(2, 1, "adc2:");
//	OLED_ShowNum(2,1,Ack ,2);
	mpu_data data;

	while(1){
		
		data = mpu6050_getData();
		OLED_ShowSignedNum(1, 1,data.acc_x, 5);
		OLED_ShowSignedNum(2, 1,data.acc_y, 5);
		OLED_ShowSignedNum(3, 1,data.acc_z, 5);
		
		OLED_ShowSignedNum(1, 8,data.gyro_x, 5);
		OLED_ShowSignedNum(2, 8,data.gyro_y, 5);
		OLED_ShowSignedNum(3, 8,data.gyro_z, 5);
		
	}
	
	
	
}




