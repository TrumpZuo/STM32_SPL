#include "iic.h"
#include "Delay.h"
#include "iic_peripheral.h"


uint8_t mpu6050_readData(uint8_t addr){
	
	IIC_Start();
	IIC_SendByte( MPU6050_ADDR);
	IIC_ReceiveAck();
	IIC_SendByte(addr);
	IIC_ReceiveAck();

//��д���	
	uint8_t data;
	IIC_Start();
	IIC_SendByte( MPU6050_ADDR | 0x01);
	IIC_ReceiveAck();
	
	data = IIC_ReceiveByte();
	IIC_SendAck(0);

	IIC_Stop();
	return data;

}

void mpu6050_writeData(uint8_t addr,uint8_t data){
	
	IIC_Start();
	IIC_SendByte( MPU6050_ADDR);
	IIC_ReceiveAck();
	IIC_SendByte(addr);
	IIC_ReceiveAck();
	IIC_SendByte(data);
	IIC_ReceiveAck();	
	IIC_Stop();
	
}

void mpu6050_init(){
	
	IIC_Init();
	Delay_us(10);
	mpu6050_writeData(MPU6050_PWR_MGMT_1,0x01);//�ر�����ģʽ��ʹ��������ʱ��
	mpu6050_writeData(MPU6050_PWR_MGMT_2,0x00);//6�� ����Ҫ����
	mpu6050_writeData(MPU6050_SMPLRT_DIV,0x09);//�����ʷ�Ƶ��10��Ƶ
	mpu6050_writeData(MPU6050_CONFIG,0x06);//��ͨ�˲���
	mpu6050_writeData(MPU6050_GYRO_CONFIG,0x18);//������ ʹ���������
	mpu6050_writeData(MPU6050_ACCEL_CONFIG,0x18);//���ٶȼƣ���ʹ�ø�ͨ�˲�
	

}

mpu_data mpu6050_getData(void){
	
	mpu_data data;
	data.acc_x = ( mpu6050_readData(MPU6050_ACCEL_XOUT_H)<<8) | mpu6050_readData(MPU6050_ACCEL_XOUT_L);
	data.acc_y = ( mpu6050_readData(MPU6050_ACCEL_YOUT_H)<<8) | mpu6050_readData(MPU6050_ACCEL_YOUT_L);
	data.acc_z = ( mpu6050_readData(MPU6050_ACCEL_ZOUT_H)<<8) | mpu6050_readData(MPU6050_ACCEL_ZOUT_L);
	
	data.gyro_x = ( mpu6050_readData(MPU6050_GYRO_XOUT_H)<<8) | mpu6050_readData(MPU6050_GYRO_XOUT_L);
	data.gyro_y = ( mpu6050_readData(MPU6050_GYRO_YOUT_H)<<8) | mpu6050_readData(MPU6050_GYRO_YOUT_L);
	data.gyro_z = ( mpu6050_readData(MPU6050_GYRO_ZOUT_H)<<8) | mpu6050_readData(MPU6050_GYRO_ZOUT_L);
	
	return data;
}
