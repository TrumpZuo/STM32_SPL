#include "stm32f10x.h"                  // Device header
#include "Delay.h"

void IIC_W_SCL(uint8_t x){
	
	GPIO_WriteBit(GPIOB, GPIO_Pin_10, (BitAction)x);
	Delay_us(10);
}
void IIC_W_SDA(uint8_t x){
	GPIO_WriteBit(GPIOB, GPIO_Pin_11, (BitAction)x);
	Delay_us(10);
}
	
uint8_t IIC_R_SDA(void){
	
	uint8_t byte;
	byte =  GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11);
	Delay_us(10);
	return byte;
}



/*���ų�ʼ��*/
void IIC_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	IIC_W_SCL(1);
	IIC_W_SDA(1);
}

/**
  * @brief  I2C��ʼ
  * @param  ��
  * @retval ��
  */
void IIC_Start(void)
{
	IIC_W_SDA(1);
	IIC_W_SCL(1);
	IIC_W_SDA(0);
	IIC_W_SCL(0);
}

/**
  * @brief  I2Cֹͣ
  * @param  ��
  * @retval ��
  */
void IIC_Stop(void)
{
	IIC_W_SDA(0);
	IIC_W_SCL(1);
	IIC_W_SDA(1);
}

/**
  * @brief  I2C����һ���ֽ�
  * @param  Byte Ҫ���͵�һ���ֽ�
  * @retval ��
  */
void IIC_SendByte(uint8_t Byte)
{
	uint8_t i;
	for (i = 0; i < 8; i++)
	{
		IIC_W_SDA(Byte & (0x80 >> i));
		IIC_W_SCL(1);
		IIC_W_SCL(0);
	}
}

/**
  * @brief  I2C����
  * @param  Ack Ӧ���ź�
  * @retval ��
  */
void IIC_SendAck(uint8_t Ack)
{
	IIC_W_SDA(Ack);
	IIC_W_SCL(1);	
	IIC_W_SCL(0);
}

/**
  * @brief  I2C����һ���ֽ�
  * @param  Byte Ҫ���͵�һ���ֽ�
  * @retval ��
  */
uint8_t IIC_ReceiveByte( void)
{
	uint8_t i;
	uint8_t byte = 0x00;
	
	IIC_W_SDA(1);
	for (i = 0; i < 8; i++)
	{
		IIC_W_SCL(1);
		if(IIC_R_SDA() == 1 ){
			byte |= (0x80>>i);
		}
		IIC_W_SCL(0);
	}
	return byte;
}

/**
  * @brief  I2C����
  * @param  Ack Ӧ���ź�
  * @retval ��
  */
uint8_t IIC_ReceiveAck(void)
{

	uint8_t Ack = 0x00;
	IIC_W_SDA(1);
	IIC_W_SCL(1);
	Ack =IIC_R_SDA();	
	IIC_W_SCL(0);
	return Ack;
}









