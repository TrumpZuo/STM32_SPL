#ifndef __TIMER_H
#define __TIMER_H
void timer_init(void);

#endif

