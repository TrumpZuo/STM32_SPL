#include "stm32f10x.h"                  // Device header
void timer_init(void){
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	NVIC_InitTypeDef  NVIC_InitStruct;
	
	//1开启时钟；
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	
	//2 选择时钟源
	TIM_InternalClockConfig(TIM2);
	
	//3.设置时基单元
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode =TIM_CounterMode_Up ;
	TIM_TimeBaseInitStruct.TIM_Period = 10000 -1;
	TIM_TimeBaseInitStruct.TIM_Prescaler = 7200 -1 ;
	TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStruct);
	
	//从0开始计数：
	//TIM_ClearFlag(TIM2,TIM_FLAG_Update);
	
	//4 中断使能
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
	
	//5 设置NVIC
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitStruct.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStruct);	
	
	//6 定时器使能，开始启动；
	TIM_Cmd(TIM2, ENABLE);
	
}

