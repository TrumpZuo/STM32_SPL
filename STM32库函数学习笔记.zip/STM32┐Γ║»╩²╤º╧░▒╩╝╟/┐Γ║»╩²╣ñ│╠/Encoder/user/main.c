#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "timer.h"
#include "encoder.h"


int16_t speed;

int main(void){
	
	OLED_Init();
	encoder_init();
	OLED_ShowString(1,1,"CNT:");
	OLED_ShowString(3,1,"speed:");
	timer_init();
	while(1){
		
		//OLED_ShowSignedNum(2,1,getCount(),5);
		OLED_ShowSignedNum(4,1,speed,5);
	}
		
}

void TIM2_IRQHandler(void){
	
	speed = getCount();//必须只在 中断中调用，不能再主函数中使用；
	TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
}

