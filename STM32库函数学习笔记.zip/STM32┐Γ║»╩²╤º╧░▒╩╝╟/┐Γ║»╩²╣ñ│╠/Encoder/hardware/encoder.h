#ifndef __ENCODER_H
#define __ENCODER_H

void encoder_init(void);
int16_t getCount(void);
#endif

